import styled from 'styled-components';

export const BTNWrapper = styled.div`
  display: flex;
  gap: 15px;
  align-items: center;
`