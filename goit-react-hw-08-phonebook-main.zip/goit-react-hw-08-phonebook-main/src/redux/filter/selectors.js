// export const selectFilter = state => state.filter.value;
export const selectFilter = state => state.filter;